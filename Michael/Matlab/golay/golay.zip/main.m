D=loadData('golay.txt');
Binary=Create_Binary(1,4095);
send=multi(D,Binary);
reverse_matrix  = reverse(D );
change_matrix_bit_19  = change_one( send,19 );
error_matrix_bit_19  = error_bit( change_matrix_bit_19,reverse_matrix );
error_vector = check_error( reverse_matrix',error_matrix_bit_19 );

